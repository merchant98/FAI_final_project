#!/bin/bash

# Build the catkin_ws
cd $(pwd)/../..; catkin_make

# Launch the nodes
xterm  -e "source devel/setup.bash; export TURTLEBOT3_MODEL=burger; roslaunch turtlebot3_gazebo turtlebot3_house.launch" &
sleep 10
xterm  -e "source devel/setup.bash; export TURTLEBOT3_MODEL=burger; roslaunch turtlebot3_navigation turtlebot3_navigation.launch map_file:=$HOME/turtle_house_map.yaml " &
sleep 5
xterm  -e "source devel/setup.bash; roslaunch turtlebot3_teleop turtlebot3_teleop_key.launch"

